@echo off
echo Building Personal Organizer Android App

echo 1. Installing dependencies...
npm install

echo 2. Building web assets...
npm run build

echo 3. Syncing with native project...
npx cap sync android

echo 4. Opening in Android Studio...
npx cap open android

echo.
echo Build complete! The project is now open in Android Studio.
echo In Android Studio, build and run the project to test on your device/emulator.
pause