// Global variables
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();
let selectedDate = null;
let events = JSON.parse(localStorage.getItem('events')) || {};
let todos = JSON.parse(localStorage.getItem('todos')) || [];
let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
let photos = JSON.parse(localStorage.getItem('photos')) || [];

// DOM Elements
const calendarDaysElement = document.getElementById('calendar-days');
const currentMonthYearElement = document.getElementById('current-month-year');
const prevMonthButton = document.getElementById('prev-month');
const nextMonthButton = document.getElementById('next-month');
const todoListElement = document.getElementById('todo-list');
const newTodoInput = document.getElementById('new-todo');
const addTodoButton = document.getElementById('add-todo');
const contactsListElement = document.getElementById('contacts-list');
const contactNameInput = document.getElementById('contact-name');
const contactPhoneInput = document.getElementById('contact-phone');
const addContactButton = document.getElementById('add-contact');
const photoUploadElement = document.getElementById('photo-upload');
const photosContainerElement = document.getElementById('photos-container');

// Event modal elements
const eventModal = document.createElement('div');
eventModal.id = 'event-modal';
eventModal.style.display = 'none';
document.body.appendChild(eventModal);

// View elements
const calendarView = document.getElementById('calendar-view-content');
const todoView = document.getElementById('todo-view-content');
const contactsView = document.getElementById('contacts-view-content');
const photosView = document.getElementById('photos-view-content');
const viewButtons = document.querySelectorAll('nav button');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js').catch(function(error) {
                console.log('Service Worker registration failed:', error);
            });
        });
    }

    // Set up event listeners
    setupEventListeners();
    
    // Initialize views
    renderCalendar(currentMonth, currentYear);
    renderTodoList();
    renderContacts();
    renderPhotos();
    
    // Show calendar view by default
    showView('calendar');
    
    // Create event modal
    createEventModal();
});

// Set up all event listeners
function setupEventListeners() {
    // Calendar navigation
    prevMonthButton.addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        renderCalendar(currentMonth, currentYear);
    });

    nextMonthButton.addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        renderCalendar(currentMonth, currentYear);
    });

    // To-Do List
    addTodoButton.addEventListener('click', addTodo);
    newTodoInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addTodo();
    });

    // Contacts
    addContactButton.addEventListener('click', addContact);
    contactPhoneInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addContact();
    });

    // Photos
    photoUploadElement.addEventListener('change', handlePhotoUpload);
    document.getElementById('take-photo').addEventListener('click', takePhoto);

    // View switching
    viewButtons.forEach(button => {
        button.addEventListener('click', () => {
            const viewId = button.id.replace('-view', '');
            showView(viewId);
        });
    });
    
    // Event modal close button
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('close-modal')) {
            eventModal.style.display = 'none';
        }
    });
}

// Show specific view
function showView(viewId) {
    // Hide all views
    document.querySelectorAll('.view').forEach(view => {
        view.classList.remove('active');
    });
    
    // Remove active class from buttons
    viewButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // Show selected view
    if (viewId === 'calendar') {
        calendarView.classList.add('active');
    } else if (viewId === 'todo') {
        todoView.classList.add('active');
    } else if (viewId === 'contacts') {
        contactsView.classList.add('active');
    } else if (viewId === 'photos') {
        photosView.classList.add('active');
    }
    
    // Set active button
    document.getElementById(`${viewId}-view`).classList.add('active');
}

// Calendar functions
function renderCalendar(month, year) {
    // Clear existing calendar
    calendarDaysElement.innerHTML = '';
    
    // Update month/year header
    const monthNames = ["January", "February", "March", "April", "May", "June",
                       "July", "August", "September", "October", "November", "December"];
    currentMonthYearElement.textContent = `${monthNames[month]} ${year}`;
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Add empty cells for days before the first day
    for (let i = 0; i < firstDay; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.classList.add('calendar-day', 'empty');
        calendarDaysElement.appendChild(emptyCell);
    }
    
    // Get today's date for comparison
    const today = new Date();
    const isCurrentMonth = (month === today.getMonth() && year === today.getFullYear());
    
    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        dayElement.classList.add('calendar-day');
        dayElement.textContent = day;
        
        // Check if this is today
        if (isCurrentMonth && day === today.getDate()) {
            dayElement.classList.add('today');
        }
        
        // Check if there are events for this day
        const dateKey = `${year}-${month}-${day}`;
        if (events[dateKey] && events[dateKey].length > 0) {
            dayElement.classList.add('has-event');
        }
        
        // Add click event to select the day
        dayElement.addEventListener('click', () => {
            selectedDate = new Date(year, month, day);
            openDayEvents(selectedDate);
        });
        
        calendarDaysElement.appendChild(dayElement);
    }
}

function openDayEvents(date) {
    const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    
    // Show event modal
    showEventModal(date, events[dateKey] || []);
}

function createEventModal() {
    eventModal.innerHTML = `
        <div id="event-modal-content">
            <span class="close-modal">&times;</span>
            <h2 id="modal-date-header"></h2>
            <div id="event-list"></div>
            <div id="event-form-container">
                <input type="text" id="event-title" placeholder="Event title" style="width: 100%; margin-bottom: 10px;">
                <input type="time" id="event-time" style="width: 100%; margin-bottom: 10px;">
                <textarea id="event-description" placeholder="Event description" style="width: 100%; margin-bottom: 10px; height: 80px;"></textarea>
                <select id="event-category" style="width: 100%; margin-bottom: 10px;">
                    <option value="personal">Personal</option>
                    <option value="work">Work</option>
                    <option value="family">Family</option>
                    <option value="other">Other</option>
                </select>
                <button id="save-event">Save Event</button>
                <button id="cancel-event">Cancel</button>
            </div>
        </div>
    `;
    
    eventModal.style.cssText = `
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
    `;
    
    document.getElementById('event-modal-content').style.cssText = `
        background-color: white;
        margin: auto;
        padding: 20px;
        border-radius: 8px;
        width: 80%;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
    `;
    
    document.querySelector('.close-modal').style.cssText = `
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        line-height: 1;
    `;
    
    document.querySelector('.close-modal').addEventListener('click', () => {
        eventModal.style.display = 'none';
    });
    
    // Add event listeners for modal buttons
    document.getElementById('save-event').addEventListener('click', saveEvent);
    document.getElementById('cancel-event').addEventListener('click', () => {
        eventModal.style.display = 'none';
    });
}

function showEventModal(date, existingEvents) {
    const dateHeader = document.getElementById('modal-date-header');
    dateHeader.textContent = `Events for ${date.toDateString()}`;
    
    const eventList = document.getElementById('event-list');
    eventList.innerHTML = '';
    
    // Display existing events
    if (existingEvents.length > 0) {
        existingEvents.forEach((event, index) => {
            const eventElement = document.createElement('div');
            eventElement.style.cssText = `
                border: 1px solid #ddd;
                padding: 10px;
                margin-bottom: 10px;
                border-radius: 4px;
                background-color: #f9f9f9;
            `;
            
            // Format time display - show "Not specified" if no time
            const timeDisplay = event.time ? event.time : 'Not specified';
            
            eventElement.innerHTML = `
                <h3>${event.title}</h3>
                <p><strong>Time:</strong> ${timeDisplay}</p>
                <p><strong>Category:</strong> ${event.category}</p>
                <p>${event.description || ''}</p>
                <button class="edit-event" data-index="${index}">Edit</button>
                <button class="delete-event" data-index="${index}">Delete</button>
            `;
            
            eventList.appendChild(eventElement);
        });
        
        // Add event listeners for edit/delete buttons
        document.querySelectorAll('.edit-event').forEach(button => {
            button.addEventListener('click', (e) => {
                const index = e.target.dataset.index;
                editEvent(date, existingEvents[index]);
            });
        });
        
        document.querySelectorAll('.delete-event').forEach(button => {
            button.addEventListener('click', (e) => {
                const index = e.target.dataset.index;
                deleteEvent(date, index);
            });
        });
    } else {
        eventList.innerHTML = '<p>No events for this day.</p>';
    }
    
    // Reset form
    document.getElementById('event-title').value = '';
    document.getElementById('event-time').value = '';
    document.getElementById('event-description').value = '';
    document.getElementById('event-category').value = 'personal';
    
    // Store date in a global variable for saving events
    window.currentEventDate = date;
    
    eventModal.style.display = 'flex';
}

function saveEvent() {
    const title = document.getElementById('event-title').value.trim();
    if (!title) return;
    
    const time = document.getElementById('event-time').value;
    const description = document.getElementById('event-description').value.trim();
    const category = document.getElementById('event-category').value;
    
    const event = {
        id: Date.now().toString(),
        title,
        time: time || null, // Make time optional
        description,
        category
    };
    
    // Get date key from global variable
    const dateKey = `${window.currentEventDate.getFullYear()}-${window.currentEventDate.getMonth()}-${window.currentEventDate.getDate()}`;
    
    if (!events[dateKey]) {
        events[dateKey] = [];
    }
    
    events[dateKey].push(event);
    saveEvents();
    
    // Refresh calendar
    renderCalendar(currentMonth, currentYear);
    
    // Close modal
    eventModal.style.display = 'none';
}

function editEvent(date, event) {
    const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    
    // Fill form with existing event data
    document.getElementById('event-title').value = event.title;
    document.getElementById('event-time').value = event.time || '';
    document.getElementById('event-description').value = event.description || '';
    document.getElementById('event-category').value = event.category || 'personal';
    
    // Remove the event from the array temporarily
    events[dateKey] = events[dateKey].filter(e => e.id !== event.id);
    saveEvents();
    
    // Show modal with save button functionality
    const saveButton = document.getElementById('save-event');
    saveButton.onclick = function() {
        saveEvent();
    };
    
    // Show modal
    showEventModal(date, events[dateKey] || []);
}

function deleteEvent(date, index) {
    const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    
    if (events[dateKey] && events[dateKey].length > index) {
        events[dateKey].splice(index, 1);
        saveEvents();
        
        // Refresh calendar
        renderCalendar(currentMonth, currentYear);
        
        // Reopen modal to show updated list
        showEventModal(date, events[dateKey] || []);
    }
}

function saveEvents() {
    localStorage.setItem('events', JSON.stringify(events));
}

// To-Do List functions
function renderTodoList() {
    todoListElement.innerHTML = '';
    
    todos.forEach((todo, index) => {
        const todoItem = document.createElement('li');
        todoItem.classList.add('todo-item');
        if (todo.completed) {
            todoItem.classList.add('completed');
        }
        
        todoItem.innerHTML = `
            <span>${todo.text}</span>
            <button class="delete-todo" data-index="${index}">Delete</button>
        `;
        
        todoListElement.appendChild(todoItem);
    });
    
    // Add event listeners to delete buttons
    document.querySelectorAll('.delete-todo').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.dataset.index;
            deleteTodo(index);
        });
    });
}

function addTodo() {
    const text = newTodoInput.value.trim();
    if (text) {
        todos.push({
            text: text,
            completed: false
        });
        saveTodos();
        renderTodoList();
        newTodoInput.value = '';
    }
}

function deleteTodo(index) {
    todos.splice(index, 1);
    saveTodos();
    renderTodoList();
}

function saveTodos() {
    localStorage.setItem('todos', JSON.stringify(todos));
}

// Contacts functions
function renderContacts() {
    contactsListElement.innerHTML = '';
    
    contacts.forEach((contact, index) => {
        const contactItem = document.createElement('li');
        contactItem.classList.add('contact-item');
        
        contactItem.innerHTML = `
            <span>${contact.name} - ${contact.phone}</span>
            <button class="delete-contact" data-index="${index}">Delete</button>
        `;
        
        contactsListElement.appendChild(contactItem);
    });
    
    // Add event listeners to delete buttons
    document.querySelectorAll('.delete-contact').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.dataset.index;
            deleteContact(index);
        });
    });
}

function addContact() {
    const name = contactNameInput.value.trim();
    const phone = contactPhoneInput.value.trim();
    
    if (name && phone) {
        contacts.push({
            name: name,
            phone: phone
        });
        saveContacts();
        renderContacts();
        contactNameInput.value = '';
        contactPhoneInput.value = '';
    }
}

function deleteContact(index) {
    contacts.splice(index, 1);
    saveContacts();
    renderContacts();
}

function saveContacts() {
    localStorage.setItem('contacts', JSON.stringify(contacts));
}

// Photos functions
function renderPhotos() {
    photosContainerElement.innerHTML = '';
    
    photos.forEach((photo, index) => {
        const photoItem = document.createElement('div');
        photoItem.classList.add('photo-item');
        
        photoItem.innerHTML = `
            <img src="${photo.dataUrl}" alt="Photo ${index + 1}" onclick="viewPhoto(${index})">
            <button class="delete-photo" data-index="${index}">×</button>
        `;
        
        photosContainerElement.appendChild(photoItem);
    });
    
    // Add event listeners to delete buttons
    document.querySelectorAll('.delete-photo').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.dataset.index;
            deletePhoto(index);
        });
    });
}

function viewPhoto(index) {
    if (index >= 0 && index < photos.length) {
        const photo = photos[index];
        const photoViewer = document.createElement('div');
        photoViewer.id = 'photo-viewer';
        photoViewer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        `;
        
        photoViewer.innerHTML = `
            <div style="position: relative; max-width: 90%; max-height: 90%;">
                <span class="close-viewer" style="position: absolute; top: 10px; right: 15px; color: white; font-size: 30px; cursor: pointer;">&times;</span>
                <img src="${photo.dataUrl}" alt="${photo.name || 'Photo'}" style="max-width: 100%; max-height: 80vh; border-radius: 8px;">
            </div>
        `;
        
        document.body.appendChild(photoViewer);
        
        // Add close functionality
        photoViewer.querySelector('.close-viewer').addEventListener('click', () => {
            document.body.removeChild(photoViewer);
        });
        
        // Close when clicking outside the image
        photoViewer.addEventListener('click', (e) => {
            if (e.target === photoViewer) {
                document.body.removeChild(photoViewer);
            }
        });
    }
}

function handlePhotoUpload(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const photoData = {
                dataUrl: e.target.result,
                name: file.name,
                date: new Date()
            };
            
            photos.push(photoData);
            savePhotos();
            renderPhotos();
        };
        reader.readAsDataURL(file);
    }
}

function takePhoto() {
    // Check if browser supports getUserMedia
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Your browser does not support camera access. Please use a modern browser.');
        return;
    }

    // Create camera view
    const cameraView = document.createElement('div');
    cameraView.id = 'camera-view';
    cameraView.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #000;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 2000;
    `;
    
    cameraView.innerHTML = `
        <video id="camera-video" style="width: 100%; max-width: 500px; height: auto;"></video>
        <div style="margin-top: 20px;">
            <button id="capture-photo" style="padding: 10px 20px; margin-right: 10px;">Capture</button>
            <button id="close-camera" style="padding: 10px 20px;">Close Camera</button>
        </div>
    `;
    
    document.body.appendChild(cameraView);
    
    // Get camera stream
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            const video = document.getElementById('camera-video');
            video.srcObject = stream;
            video.play();
            
            // Capture photo when button is clicked
            document.getElementById('capture-photo').addEventListener('click', () => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0);
                
                // Stop the stream
                stream.getTracks().forEach(track => track.stop());
                
                // Save the photo
                const photoData = {
                    dataUrl: canvas.toDataURL('image/jpeg'),
                    name: `photo_${new Date().toISOString()}.jpg`,
                    date: new Date()
                };
                
                photos.push(photoData);
                savePhotos();
                renderPhotos();
                
                // Close camera view
                document.body.removeChild(cameraView);
            });
            
            // Close camera when button is clicked
            document.getElementById('close-camera').addEventListener('click', () => {
                stream.getTracks().forEach(track => track.stop());
                document.body.removeChild(cameraView);
            });
        })
        .catch(err => {
            console.error("Error accessing camera:", err);
            alert('Could not access the camera. Please make sure you have granted permission.');
            document.body.removeChild(cameraView);
        });
}

function deletePhoto(index) {
    photos.splice(index, 1);
    savePhotos();
    renderPhotos();
}

function savePhotos() {
    localStorage.setItem('photos', JSON.stringify(photos));
}

// Service Worker registration (will be created in sw.js)