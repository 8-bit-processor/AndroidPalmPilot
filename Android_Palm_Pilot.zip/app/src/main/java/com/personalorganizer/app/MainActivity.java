package com.personalorganizer.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
