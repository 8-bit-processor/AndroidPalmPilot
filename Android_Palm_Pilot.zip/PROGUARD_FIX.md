# ProGuard Configuration Fix

## Issue Identified
The error occurs in `@capacitor/camera/android/build.gradle` at line 47 where it uses deprecated `getDefaultProguardFile('proguard-android.txt')` instead of the newer `getDefaultProguardFile('proguard-android-optimize.txt')`.

## Solution

### Manual Fix for Capacitor Camera Plugin:

1. **Navigate to**: 
   ```
   C:\Users\guest user\Desktop\vibe-workspace\webAndroidApp\node_modules\@capacitor\camera\android
   ```

2. **Open** `build.gradle` file (line 47)

3. **Change**:
   ```gradle
   getDefaultProguardFile('proguard-android.txt')
   ```
   
   **To**:
   ```gradle
   getDefaultProguardFile('proguard-android-optimize.txt')
   ```

### Alternative Quick Fix:

Since this is a dependency issue, you can also:

1. **In your project's `android/app/build.gradle`**, add this workaround:
   ```gradle
   android {
       compileSdkVersion rootProject.ext.compileSdkVersion
   
       defaultConfig {
           // ... existing config
           proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
       }
   }
   ```

### Permanent Solution:

1. **Update Capacitor dependencies**:
   ```bash
   npm install @capacitor/core @capacitor/camera --save
   ```

2. **Rebuild the project**:
   ```bash
   npx cap sync android
   ```

## After Fixing:
1. **Clean Project**: Build → Clean Project in Android Studio
2. **Make Project**: Build → Make Project 
3. **Run App**: Click green run button

The app should now build and run without ProGuard errors.