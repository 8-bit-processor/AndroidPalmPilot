#!/bin/bash

echo "Building Personal Organizer Android App"

# Check if node is installed
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed"
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "Error: npm is not installed"
    exit 1
fi

echo "1. Installing dependencies..."
npm install

echo "2. Building web assets..."
npm run build

echo "3. Adding Android platform..."
npx cap add android

echo "4. Syncing with native project..."
npx cap sync android

echo "5. Opening in Android Studio..."
npx cap open android

echo ""
echo "Build complete! The project is now open in Android Studio."
echo "In Android Studio, build and run the project to test on your device/emulator."