@echo off
echo Fixing Java Home Configuration for Android Build
echo.

REM Set JAVA_HOME to match the Gradle JDK location
set JAVA_HOME=C:\Users\guest user\.jdks\jbr-21.0.11

echo JAVA_HOME has been set to: %JAVA_HOME%
echo.
echo Please restart Android Studio and try building again.
echo.
echo If you still have issues, you can also:
echo 1. Set JAVA_HOME in Windows Environment Variables
echo 2. Or run Android Studio with the correct JDK path
echo.

pause