// Simple build script for web app
const fs = require('fs');
const path = require('path');

// Create dist directory if it doesn't exist
if (!fs.existsSync('dist')) {
  fs.mkdirSync('dist');
}

// Copy all necessary files to dist directory
const filesToCopy = [
  'index.html',
  'styles.css', 
  'app.js',
  'manifest.json',
  'sw.js',
  'favicon.ico'
];

filesToCopy.forEach(file => {
  if (fs.existsSync(file)) {
    fs.copyFileSync(file, path.join('dist', file));
    console.log(`Copied ${file} to dist/`);
  }
});

console.log('Web app build complete!');