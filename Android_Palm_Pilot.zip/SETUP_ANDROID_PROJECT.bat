@echo off
echo =================================================
echo Setting up Personal Organizer Android Project
echo =================================================
echo.

echo 1. Installing dependencies...
npm install

echo 2. Building web assets...
npm run build

echo 3. Syncing with Android project...
npx cap sync android

echo 4. Fixing Java configuration...
set JAVA_HOME=C:\Users\guest user\.jdks\jbr-21.0.11

echo 5. Opening Android Studio...
npx cap open android

echo.
echo =================================================
echo Setup Complete!
echo Your Android project is ready in the android/ folder
echo Open it in Android Studio and build/run the app
echo =================================================
echo.

pause